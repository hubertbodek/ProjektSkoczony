﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjektPO
{
    interface IBaza
    {
        void Ranking();
        void SortujNazwa();
        void SortujRokPowstania();
    }
}
